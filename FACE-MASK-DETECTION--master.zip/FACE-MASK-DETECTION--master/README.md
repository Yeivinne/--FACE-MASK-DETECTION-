# Face Mask Detection

🔴 Follow this video to learn:

[![Alt text](https://raw.githubusercontent.com/pik1989/FaceMaskDetection/main/face_detector/Face%20Mask%20Detection%20using%20Python%2C%20Keras%2C%20OpenCV%20and%20MobileNet%20Detect%20masks%20real-time%20video%20streams.JPG)](https://youtu.be/krTHVKkUEYw)

